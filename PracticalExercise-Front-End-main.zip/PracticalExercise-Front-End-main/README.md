![University Logo](https://uom.lk/sites/default/files/logoUoM_0_0.png)
>Orientation Programme - Batch 21
>University of Moratuwa
>Faculty of Information Technology


# PracticleExercise-Front-End

Design and develop the Front-end (i.e. User Interfaces) of the selected website using HTML, CSS, and JavaScript.

```Cloning a sample webstie UI which offer Online Courses```

## Languages used to clone
- HTML
- CSS
- Java Script
- [SWIPER](https://swiperjs.com/)

## External Sites used to Structure & Styles and Functions
- for icons [iconsocut](https://iconscout.com/)
- for fonts [google fonts](https://fonts.google.com/)
- for forms [formspree](https://formspree.io/)


### Contributors

- Leader - 215094P [RAJAPAKSHA R.V.K.J.](https://github.com/KasunJayasanka)
- Member - 215062R [Kavinda R.L.M.](https://github.com/MalinthaKavinda)
- Member - 215123G [Weerasinghe W.P.A.S.](https://github.com/AmashaWeerasinghe)
- Member - 215072X [Maheshika M.A.M.](https://github.com/Mihiliiyamaheshika)

#### Final Submission

- On or before 17<sup>th</sup>July 2022 - 11.59 P.M

#### Demonstration

- On 20<sup>th</sup>July 2022 - 10.15 A.M
- Breakout Room No - 3
- Done Successfully :)






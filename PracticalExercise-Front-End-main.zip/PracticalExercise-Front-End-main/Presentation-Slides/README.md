## Presentation Slides Which created by All members

## Slide Division


### Kasun
- Cover
- Welcome
- Team Members
- Languages Used
- Github
- HomePage
- Conclusion

### Amasha

- What We Selected
- Contact Page

### Mihiliya

- Why we select
- Courses Page

### Malintha

- Workload Division
- AboutUs Page
